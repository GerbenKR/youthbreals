import{m as a,a as e}from"./alpinejs-CnGfEmWN.js";const o=()=>({open:!1,openNavigation(){this.open=!0},closeNavigation(){this.open=!1}});a.plugin(e);a.data("Header",o);a.start();
